// --- 1. BIẾN TRẠNG THÁI ---
let isHuman = false;
let isVerifying = false;

// --- 2. CƠ SỞ DỮ LIỆU MẪU ---
const database = [
    { name: "Nguyễn Văn A", dob: "2005-10-15", gender: "Nam", math: 8.5, physics: 7.0, chemistry: 9.0 },
    { name: "Nguyễn Văn A", dob: "2005-02-20", gender: "Nam", math: 6.0, physics: 6.5, chemistry: 7.0 },
    { name: "Trần Thị B", dob: "2005-11-05", gender: "Nữ", math: 9.0, physics: 8.5, chemistry: 8.0 }
];

// --- 3. HIỆU ỨNG CHỌN GIỚI TÍNH ---
document.getElementById("studentGender").addEventListener("change", function() {
    this.classList.remove("gender-male", "gender-female");
    void this.offsetWidth;

    if (this.value === "Nam") {
        this.classList.add("gender-male");
    } else if (this.value === "Nữ") {
        this.classList.add("gender-female");
    } else {
        this.style.borderColor = "#ddd";
        this.style.color = "#444";
        this.style.backgroundColor = "#fff";
        this.style.boxShadow = "none";
    }
});

// --- 4. RECAPTCHA ---
function verifyRecaptcha() {
    if (isHuman || isVerifying) return;

    document.getElementById("recaptchaError").classList.add("hidden");
    isVerifying = true;

    const checkbox = document.getElementById('rc-checkbox');
    const spinner = document.getElementById('rc-spinner');
    const check = document.getElementById('rc-check');

    checkbox.style.border = 'none';
    checkbox.style.background = 'transparent';
    spinner.classList.remove('rc-hidden');

    setTimeout(() => {
        spinner.classList.add('rc-hidden');
        check.classList.remove('rc-hidden');
        isHuman = true;
        isVerifying = false;
    }, 1500);
}

function resetRecaptcha() {
    isHuman = false;
    const checkbox = document.getElementById('rc-checkbox');
    const spinner = document.getElementById('rc-spinner');
    const check = document.getElementById('rc-check');
    const recaptchaBox = document.getElementById('recaptchaBox');

    checkbox.style.border = '2px solid #c1c1c1';
    checkbox.style.background = '#fff';
    spinner.classList.add('rc-hidden');
    check.classList.add('rc-hidden');
    recaptchaBox.classList.remove("input-error");
}

// --- 5. NÚT XÓA FORM ---
function resetForm() {
    document.getElementById("studentName").value = "";
    document.getElementById("studentDob").value = "";

    const genderInput = document.getElementById("studentGender");
    genderInput.value = "";
    genderInput.dispatchEvent(new Event('change')); // Kích hoạt sự kiện đổi màu

    document.getElementById("resultContainer").classList.add("hidden");
    document.getElementById("errorContainer").classList.add("hidden");
    document.getElementById("recaptchaError").classList.add("hidden");

    resetRecaptcha();

    // Xóa class lỗi nếu đang rung
    document.getElementById("studentName").classList.remove("input-error");
    document.getElementById("studentDob").classList.remove("input-error");
    document.getElementById("studentGender").classList.remove("input-error");
}

// --- 6. HÀM TRA CỨU CHÍNH ---
function searchResult() {
    const nameInput = document.getElementById("studentName");
    const dobInput = document.getElementById("studentDob");
    const genderInput = document.getElementById("studentGender");

    const resultContainer = document.getElementById("resultContainer");
    const errorContainer = document.getElementById("errorContainer");

    nameInput.classList.remove("input-error");
    dobInput.classList.remove("input-error");
    genderInput.classList.remove("input-error");
    resultContainer.classList.add("hidden");
    errorContainer.classList.add("hidden");

    const inputName = nameInput.value.trim().toLowerCase();
    const inputDob = dobInput.value;
    const inputGender = genderInput.value;

    let hasError = false;

    if (inputName === "") {
        nameInput.classList.add("input-error");
        hasError = true;
    }
    if (inputDob === "") {
        dobInput.classList.add("input-error");
        hasError = true;
    }
    if (inputGender === "") {
        genderInput.classList.add("input-error");
        hasError = true;
    }

    if (hasError) {
        setTimeout(() => {
            nameInput.classList.remove("input-error");
            dobInput.classList.remove("input-error");
            genderInput.classList.remove("input-error");
        }, 400);
        return;
    }

    if (!isHuman) {
        const recaptchaBox = document.getElementById("recaptchaBox");
        const recaptchaError = document.getElementById("recaptchaError");

        recaptchaError.classList.remove("hidden");
        recaptchaBox.classList.add("input-error");

        setTimeout(() => {
            recaptchaBox.classList.remove("input-error");
        }, 400);
        return;
    }

    // Lọc dữ liệu
    const matchedStudents = database.filter(student =>
        student.name.toLowerCase() === inputName &&
        student.dob === inputDob &&
        student.gender === inputGender
    );

    if (matchedStudents.length > 0) {
        let htmlContent = "";

        matchedStudents.forEach(student => {
            const totalScore = (student.math + student.physics + student.chemistry).toFixed(2);
            const dateObj = new Date(student.dob);
            const displayDob = `${dateObj.getDate()}/${dateObj.getMonth() + 1}/${dateObj.getFullYear()}`;

            htmlContent += `
                <div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid #ddd;">
                    <h3 style="color: #4a90e2; margin-bottom: 5px;">Thí sinh: ${student.name}</h3>
                    <p style="color: #666; font-size: 13px; margin-bottom: 15px;">
                        Ngày sinh: ${displayDob} | Giới tính: <strong>${student.gender}</strong>
                    </p>
                    
                    <div class="score-item">
                        <span>Toán học:</span>
                        <span>${student.math}</span>
                    </div>
                    <div class="score-item">
                        <span>Vật lý:</span>
                        <span>${student.physics}</span>
                    </div>
                    <div class="score-item">
                        <span>Hóa học:</span>
                        <span>${student.chemistry}</span>
                    </div>
                    <div class="score-item">
                        <span>Tổng điểm:</span>
                        <span>${totalScore}</span>
                    </div>
                </div>
            `;
        });

        resultContainer.innerHTML = htmlContent;
        resultContainer.classList.remove("hidden");
        resetRecaptcha();

    } else {
        errorContainer.classList.remove("hidden");
        resetRecaptcha();
    }
}

// Bắt sự kiện phím Enter
document.getElementById("studentName").addEventListener("keypress", function(event) {
    if (event.key === "Enter") searchResult();
});