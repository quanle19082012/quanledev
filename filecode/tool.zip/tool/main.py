"""
HaToKi FTool - Công cụ lọc dòng chứa từ khóa trong file .txt
Tác giả: HaToKi
Mô tả: Ứng dụng GUI với dark theme, hỗ trợ tìm kiếm không phân biệt hoa thường,
        xử lý file lớn, xuất kết quả ra output.txt
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
import sys

class HaToKiFTool:
    def __init__(self, root):
        self.root = root
        self.root.title("HaToKi FTool")
        self.root.geometry("700x500")
        self.root.minsize(600, 400)
        
        # Biến lưu đường dẫn file
        self.file_path = tk.StringVar()
        
        # Thiết lập dark theme
        self.setup_dark_theme()
        
        # Tạo giao diện
        self.create_widgets()
        
        # Đặt icon nếu có (tùy chọn)
        # self.root.iconbitmap("icon.ico") 
        
        # Center window
        self.center_window()
    
    def setup_dark_theme(self):
        """Cấu hình dark theme cho toàn bộ ứng dụng"""
        self.bg_color = "#1e1e1e"
        self.fg_color = "#ffffff"
        self.accent_color = "#007acc"
        self.button_bg = "#0e639c"
        self.button_fg = "#ffffff"
        self.entry_bg = "#2d2d2d"
        self.entry_fg = "#d4d4d4"
        self.progress_bg = "#3c3c3c"
        
        self.root.configure(bg=self.bg_color)
        
        # Style cho ttk
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("TLabel", background=self.bg_color, foreground=self.fg_color, font=("Segoe UI", 10))
        style.configure("TButton", background=self.button_bg, foreground=self.button_fg, 
                       font=("Segoe UI", 10), borderwidth=0, focuscolor="none")
        style.map("TButton", background=[("active", "#1177bb")])
        
        style.configure("TProgressbar", background=self.accent_color, troughcolor=self.progress_bg)
        
        style.configure("TFrame", background=self.bg_color)
        style.configure("TLabelframe", background=self.bg_color, foreground=self.fg_color)
        style.configure("TLabelframe.Label", background=self.bg_color, foreground=self.fg_color)
    
    def center_window(self):
        """Căn giữa cửa sổ trên màn hình"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        """Tạo các thành phần giao diện"""
        # ================= Phần 1: Chọn file =================
        file_frame = ttk.LabelFrame(self.root, text="📁 Chọn file đầu vào", padding=10)
        file_frame.pack(fill="x", padx=20, pady=10)
        
        self.file_entry = ttk.Entry(file_frame, textvariable=self.file_path, font=("Segoe UI", 9))
        self.file_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        self.browse_btn = ttk.Button(file_frame, text="Duyệt...", command=self.browse_file)
        self.browse_btn.pack(side="right")
        
        # ================= Phần 2: Từ khóa =================
        keyword_frame = ttk.LabelFrame(self.root, text="🔍 Từ khóa cần tìm", padding=10)
        keyword_frame.pack(fill="x", padx=20, pady=10)
        
        self.keyword_entry = ttk.Entry(keyword_frame, font=("Segoe UI", 11))
        self.keyword_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.keyword_entry.bind("<Return>", lambda event: self.start_search())
        
        self.find_btn = ttk.Button(keyword_frame, text="Find", command=self.start_search)
        self.find_btn.pack(side="right")
        
        # ================= Phần 3: Thanh tiến trình =================
        progress_frame = ttk.Frame(self.root)
        progress_frame.pack(fill="x", padx=20, pady=10)
        
        self.progress = ttk.Progressbar(progress_frame, mode="determinate")
        self.progress.pack(fill="x")
        
        self.status_label = ttk.Label(progress_frame, text="Sẵn sàng", font=("Segoe UI", 9))
        self.status_label.pack(pady=(5, 0))
        
        # ================= Nút mở thư mục =================
        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill="x", padx=20, pady=10)
        
        self.open_folder_btn = ttk.Button(button_frame, text="📂 Mở thư mục chứa kết quả", 
                                         command=self.open_output_folder, state="disabled")
        self.open_folder_btn.pack(side="left", padx=(0, 10))
        
        # ================= Khu vực hiển thị log =================
        log_frame = ttk.LabelFrame(self.root, text="📋 Nhật ký", padding=10)
        log_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.log_text = tk.Text(log_frame, height=8, bg="#2d2d2d", fg="#d4d4d4",
                               font=("Consolas", 9), wrap="word", relief="flat")
        self.log_text.pack(side="left", fill="both", expand=True)
        
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        scrollbar.pack(side="right", fill="y")
        self.log_text.configure(yscrollcommand=scrollbar.set)
        
        # Thêm watermark
        watermark = ttk.Label(self.root, text="HaToKi FTool © 2026", font=("Segoe UI", 8), foreground="#555555")
        watermark.pack(side="bottom", pady=5)
    
    def browse_file(self):
        """Mở hộp thoại chọn file .txt"""
        filename = filedialog.askopenfilename(
            title="Chọn file txt cần lọc",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.file_path.set(filename)
            self.log(f"✅ Đã chọn file: {filename}")
    
    def log(self, message):
        """Ghi log vào khung văn bản"""
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.root.update_idletasks()
    
    def start_search(self):
        """Bắt đầu quá trình tìm kiếm trong luồng riêng"""
        if not self.file_path.get():
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn file đầu vào!")
            return
        
        keyword = self.keyword_entry.get().strip()
        if not keyword:
            messagebox.showwarning("Cảnh báo", "Vui lòng nhập từ khóa cần tìm!")
            return
        
        # Disable nút trong khi xử lý
        self.find_btn.config(state="disabled")
        self.browse_btn.config(state="disabled")
        self.open_folder_btn.config(state="disabled")
        self.progress["value"] = 0
        self.status_label.config(text="Đang xử lý...")
        
        # Chạy trong thread riêng để không treo giao diện
        thread = threading.Thread(target=self.process_file, args=(keyword,), daemon=True)
        thread.start()
    
    def process_file(self, keyword):
        """Xử lý file: đọc từng dòng, lọc, ghi ra output.txt"""
        input_path = self.file_path.get()
        output_path = os.path.join(os.path.dirname(sys.argv[0]), "output.txt")
        
        try:
            # Đếm tổng số dòng để cập nhật progress bar
            self.log("📊 Đang đếm số dòng trong file...")
            total_lines = 0
            with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                for _ in f:
                    total_lines += 1
            
            if total_lines == 0:
                self.root.after(0, self.finish_search, False, "File không có dòng nào để xử lý!")
                return
            
            self.log(f"📄 Tổng số dòng: {total_lines:,}")
            self.log(f"🔎 Đang tìm kiếm từ khóa: '{keyword}' (không phân biệt hoa thường)")
            
            # Đọc và lọc từng dòng
            matched_count = 0
            processed = 0
            
            with open(input_path, 'r', encoding='utf-8', errors='ignore') as infile, \
                 open(output_path, 'w', encoding='utf-8') as outfile:
                
                for line in infile:
                    # Xóa ký tự xuống dòng cuối và kiểm tra
                    if keyword.lower() in line.lower():
                        outfile.write(line)
                        matched_count += 1
                    
                    processed += 1
                    # Cập nhật progress bar mỗi 1000 dòng hoặc 1% để tối ưu
                    if processed % 1000 == 0 or processed == total_lines:
                        progress_val = int((processed / total_lines) * 100)
                        self.root.after(0, self.update_progress, progress_val)
            
            # Hoàn thành
            result_msg = f"✅ Hoàn tất! Tìm thấy {matched_count:,} dòng chứa từ khóa.\n📁 Kết quả được lưu tại: {output_path}"
            self.root.after(0, self.finish_search, True, result_msg)
            
        except FileNotFoundError:
            self.root.after(0, self.finish_search, False, f"❌ Không tìm thấy file: {input_path}")
        except PermissionError:
            self.root.after(0, self.finish_search, False, "❌ Lỗi quyền truy cập file!")
        except Exception as e:
            self.root.after(0, self.finish_search, False, f"❌ Lỗi không xác định: {str(e)}")
    
    def update_progress(self, value):
        """Cập nhật thanh tiến trình"""
        self.progress["value"] = value
        self.status_label.config(text=f"Đang xử lý... {value}%")
        self.root.update_idletasks()
    
    def finish_search(self, success, message):
        """Kết thúc quá trình tìm kiếm, hiển thị thông báo"""
        self.find_btn.config(state="normal")
        self.browse_btn.config(state="normal")
        
        if success:
            self.progress["value"] = 100
            self.status_label.config(text="Hoàn tất 100%")
            self.log(message)
            messagebox.showinfo("Thành công", "Đã tạo file output.txt thành công.")
            self.open_folder_btn.config(state="normal")
        else:
            self.status_label.config(text="Lỗi")
            self.log(message)
            messagebox.showerror("Lỗi", message)
    
    def open_output_folder(self):
        """Mở thư mục chứa output.txt"""
        output_path = os.path.join(os.path.dirname(sys.argv[0]), "output.txt")
        folder_path = os.path.dirname(output_path)
        
        if os.path.exists(output_path):
            # Mở thư mục và chọn file output.txt (Windows/macOS/Linux)
            if sys.platform == "win32":
                os.startfile(folder_path)
            elif sys.platform == "darwin":  # macOS
                os.system(f'open "{folder_path}"')
            else:  # Linux
                os.system(f'xdg-open "{folder_path}"')
            self.log(f"📂 Đã mở thư mục: {folder_path}")
        else:
            messagebox.showwarning("Cảnh báo", "Chưa có file output.txt nào được tạo!")

# ================= Chạy ứng dụng =================
if __name__ == "__main__":
    root = tk.Tk()
    app = HaToKiFTool(root)
    root.mainloop()